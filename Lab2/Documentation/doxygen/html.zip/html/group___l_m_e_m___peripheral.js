var group___l_m_e_m___peripheral =
[
    [ "LMEM - Register accessor macros", "group___l_m_e_m___register___accessor___macros.html", null ],
    [ "LMEM Register Masks", "group___l_m_e_m___register___masks.html", null ],
    [ "LMEM_MemMap", "struct_l_m_e_m___mem_map.html", [
      [ "PCCCR", "struct_l_m_e_m___mem_map.html#a6c1a7b2233d1c876439a885960f24960", null ],
      [ "PCCCVR", "struct_l_m_e_m___mem_map.html#a0dd1ccb32a70f4e5463d84acebc78cf0", null ],
      [ "PCCLCR", "struct_l_m_e_m___mem_map.html#ad88f5f6b11fe26dbd6065a1767e6f4df", null ],
      [ "PCCRMR", "struct_l_m_e_m___mem_map.html#afd9bb5dd96464953c7be37e55627192e", null ],
      [ "PCCSAR", "struct_l_m_e_m___mem_map.html#a2580365cbac4d397893ac168db87fa4d", null ],
      [ "PSCCR", "struct_l_m_e_m___mem_map.html#ad26f05e85cf69da9518f970a37bf8c39", null ],
      [ "PSCCVR", "struct_l_m_e_m___mem_map.html#a4d271cf6da70b234d27d64eae216d3b7", null ],
      [ "PSCLCR", "struct_l_m_e_m___mem_map.html#a9002773a5254b5d1ebb9a46218ef21c4", null ],
      [ "PSCRMR", "struct_l_m_e_m___mem_map.html#a06dad54d3dcb178443d2c9b0d5ae2496", null ],
      [ "PSCSAR", "struct_l_m_e_m___mem_map.html#ad54ebfe0c32863df5645bc4416dfe3dc", null ],
      [ "RESERVED_0", "struct_l_m_e_m___mem_map.html#a615e4c9bb609333b5438cd34753a02cb", null ],
      [ "RESERVED_1", "struct_l_m_e_m___mem_map.html#a12dd9bc83a1593b030c19cdfac8c915a", null ],
      [ "RESERVED_2", "struct_l_m_e_m___mem_map.html#a465302eb3bc6bbd7853799c24fb20b7f", null ]
    ] ],
    [ "LMEM_BASE_PTR", "group___l_m_e_m___peripheral.html#ga1666dc97b6d56a81369b43b1ee4ae240", null ],
    [ "LMEM_BASE_PTRS", "group___l_m_e_m___peripheral.html#ga3b8cec218a8a57a762a94905faf149b4", null ],
    [ "LMEM_MemMapPtr", "group___l_m_e_m___peripheral.html#gad8e02e2903502eea2a0cc497a0dde6d8", null ]
];