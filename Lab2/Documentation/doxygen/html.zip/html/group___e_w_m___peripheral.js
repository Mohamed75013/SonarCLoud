var group___e_w_m___peripheral =
[
    [ "EWM - Register accessor macros", "group___e_w_m___register___accessor___macros.html", null ],
    [ "EWM Register Masks", "group___e_w_m___register___masks.html", null ],
    [ "EWM_MemMap", "struct_e_w_m___mem_map.html", [
      [ "CMPH", "struct_e_w_m___mem_map.html#a88293412bcc664b463f1fef25312c4ab", null ],
      [ "CMPL", "struct_e_w_m___mem_map.html#ada0221f7554297f23a0257f54f28f5fc", null ],
      [ "CTRL", "struct_e_w_m___mem_map.html#a033a88d44ad1daa23ce3deb13bc94811", null ],
      [ "SERV", "struct_e_w_m___mem_map.html#aa9c25d4775f785d6911e096a226f4e40", null ]
    ] ],
    [ "EWM_BASE_PTR", "group___e_w_m___peripheral.html#gae3454b5b37183b746362498d1fafc40c", null ],
    [ "EWM_BASE_PTRS", "group___e_w_m___peripheral.html#ga8b79ee9e363583bee6122ee3da7952b2", null ],
    [ "EWM_MemMapPtr", "group___e_w_m___peripheral.html#ga1de35bc04fc7fa4929507210147339a6", null ]
];