var NAVTREE =
[
  [ "Lab3", "index.html", [
    [ "Pins allocation", "page_pinalloc.html", null ],
    [ "Memory map", "page_memorymap.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_a_d_c___p_d_d_8h_source.html",
"globals_l.html",
"group___a_d_c___register___masks.html#ga9f8f5b63268c5b87f04ee884579a385b",
"group___a_i_p_s___register___masks.html#ga3059ddbcdb481c14c1c4475f0c7a2187",
"group___a_i_p_s___register___masks.html#ga74127c75240a56d4ab6fc6ec9e9c3e3d",
"group___a_i_p_s___register___masks.html#gacba4e2743a846f34382eb36a1b5b96fb",
"group___a_x_b_s___register___masks.html#ga6a2c79e55f5424e6d4e863a6f51c8250",
"group___c_a_n___register___accessor___macros.html#gad81afd5c2ce4d4b51135eb982b2ec37d",
"group___c_a_n___register___masks.html#gae3dd7acc84e521ca0a05beb33f7b434c",
"group___c_a_u___register___masks.html#ga371852a2013f6f7d79b8fcd434367358",
"group___c_a_u___register___masks.html#gaf09e50e24d96bd92db37a730123748c0",
"group___c_r_c___register___masks.html#ga1d62eb284fb7d178fddaf03e10dcd19c",
"group___d_a_c___register___masks.html#gaacd61446351eecf90f0c04eed83ef08f",
"group___d_d_r___register___masks.html#ga30a600af23cfd356053e29d0969a30ae",
"group___d_d_r___register___masks.html#gab08166185809739db4a44e36f44ef2e1",
"group___d_m_a___register___accessor___macros.html#ga20dd71cc6246dba8d54263a5244d8462",
"group___d_m_a___register___accessor___macros.html#ga8751f24b9f2e3d213a219e5b42f9e642",
"group___d_m_a___register___accessor___macros.html#gaf41fc8b22a17c04de85620c111044270",
"group___d_m_a___register___masks.html#ga4561a1738dbf8013bd619fad65b0e216",
"group___d_m_a___register___masks.html#ga8d8a7a23ba67b0dd3830251a3ce561d3",
"group___d_m_a___register___masks.html#gad9a9fad542ba546abdd79542b30a5cb7",
"group___e_n_e_t___register___accessor___macros.html#ga05a53356a6b14f87c5efbb26d2858479",
"group___e_n_e_t___register___masks.html#ga20649e66e27490be23302b4c87e979b8",
"group___e_n_e_t___register___masks.html#gab12c920d9e9f6383e5981fb59764e3a9",
"group___e_t_f___register___accessor___macros.html#ga3725c13fdb2033c92131c8abf3367aa1",
"group___f_b___register___masks.html#gad89987be24118d73c55bf5e97ab5e8d7",
"group___f_p_b___register___accessor___macros.html#gac97cbee200bbd12a267ec742005eaa0f",
"group___f_t_m___register___accessor___macros.html#ga66d5c878f519d81756a956cab059badf",
"group___f_t_m___register___masks.html#ga70e29e6856263443f9415464e8c88d35",
"group___g_p_i_o___register___accessor___macros.html#ga5377d98699ff945b7e797db51a200c3f",
"group___i2_s___register___accessor___macros.html#gac920c2084f1555a5696e637e5231ecfa",
"group___i_t_m___register___accessor___macros.html#ga20b6604c5d16c42c91578bb58acc8249",
"group___interrupt__vector__numbers.html#gga5f3656e2a154b64aa378a2f3856c3a8daa8efc63b005ab6816e2b5457fa42244d",
"group___l_c_d_c___register___masks.html#ga819fab8d5184f4f4f6c39a50544d8150",
"group___l_l_w_u___register___masks.html#gad0111a325ce3f549a1726373cde88f96",
"group___l_p_t_m_r___register___accessor___macros.html#gac2f4b2b992990404896f3b23f4d666cb",
"group___m_c_m___register___masks.html#ga1d21eead21628e992564620393e8ebf0",
"group___m_p_u___register___masks.html#ga7409b2905721fcdbd64058717f0f97af",
"group___n_f_c___register___masks.html#gabdd22eb41619d9857dd7c7ba9650fd0f",
"group___n_v_i_c___register___accessor___macros.html#gab5f93e5f778f20502398ca5168147f91",
"group___n_v_i_c___register___masks.html#ga9d795094f3e5be211ceeb25b4e20a015",
"group___p_d_b___register___masks.html#ga8632d420c92ec79e08c43f7d3acc79cf",
"group___p_e___types__module.html#ga075a58b6f98ebcea0ec48301f75f9500",
"group___p_e___types__module.html#ga2743c651426fe1f2aa2e7cdcb858740e",
"group___p_e___types__module.html#ga44c2a5a0aac5f538115210803b5e25bd",
"group___p_e___types__module.html#ga67c9ed9bde8dbe2878eb2f074df3cff4",
"group___p_e___types__module.html#ga8af21cbad27c8d061a98924a11fc5a9b",
"group___p_e___types__module.html#gaaf4303ab0c84575eba1d40cee669a809",
"group___p_e___types__module.html#gacf657b2b5230f66e5019218862ac33b4",
"group___p_e___types__module.html#gaf1734ecb6fe6569c872630d13c3ee367",
"group___p_e___types__module.html#gga59054b7863240b77bde12e8762d3da5aad8e8989c445e987c9491a1df1bfa93d6",
"group___p_e___types__module.html#ggac01cb076a7d214b9644c76681280e031aeaafd5d96e73905acf5b31aa5177abb6",
"group___p_o_r_t___register___accessor___macros.html",
"group___p_o_r_t___register___masks.html#ga18556773988cdd78e363959884dbec46",
"group___r_t_c___register___masks.html#ga1882e75b5cd193e98d54d3814660b71e",
"group___s_c_b___register___masks.html#ga6a1d724f4fe22533bd37c3f5179d2219",
"group___s_d_h_c___register___masks.html#ga373ff5b200a397f6c4a71a9e831ee6c8",
"group___s_d_h_c___register___masks.html#gaefb26b10e16d07a763c3a6aa87d64c77",
"group___s_i_m___register___masks.html#ga7b7b645afc3ee38683f7e4d9d300e653",
"group___s_p_i___register___accessor___macros.html#ga2025336cecfcf0c5b7cdb30e8056505b",
"group___sys_tick___peripheral.html",
"group___t_s_i___register___masks.html#gab5aa48e30efdd8e8f431087e7c115ef0",
"group___u_a_r_t___register___accessor___macros.html#gaf408be28f737716d8e617f2b5c26e6c3",
"group___u_a_r_t___register___masks.html#gac04113c9c307f88a4e51db472d274eee",
"group___u_s_b___register___masks.html#ga6e2ea6a3166748c567d22a767c69f98d",
"group___u_s_b_h_s___register___accessor___macros.html#ga9af58e813ed1a9811acc10b7275d9aae",
"group___u_s_b_h_s___register___masks.html#ga6c1509fda3abee1b550e1204bb67fdbf",
"group___u_s_b_h_s___register___masks.html#gaf1ca831184eb56dc26f7d813e1698430",
"struct_a_x_b_s___mem_map.html#a952d7f281eaf5fba221d0f1d3292f01b",
"struct_d_m_a___mem_map.html#ad3fdbf296bf5056b5b5cbc525aa2941c",
"struct_e_t_m___mem_map.html#a2c7a3f8cfd949e68ccecc4440f24636e",
"struct_l_d_d___c_a_n___t_frame.html",
"struct_l_d_d___u_s_b___device___t_t_d___struct.html#aaff3a74a2abea1e6b530ecfdaff8c584",
"struct_p_i_t___mem_map.html",
"struct_t_s_i___mem_map.html#a73d4134257f7351180c72870359b2bbf",
"unionuint32union__t.html#a02b7aaa4708411c52446dc5528f66c25"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';