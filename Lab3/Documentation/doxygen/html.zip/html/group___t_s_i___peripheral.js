var group___t_s_i___peripheral =
[
    [ "TSI - Register accessor macros", "group___t_s_i___register___accessor___macros.html", null ],
    [ "TSI Register Masks", "group___t_s_i___register___masks.html", null ],
    [ "TSI_MemMap", "struct_t_s_i___mem_map.html", [
      [ "CNTR1", "struct_t_s_i___mem_map.html#a04fc03ca20b588fb20be9eee512fbfeb", null ],
      [ "CNTR11", "struct_t_s_i___mem_map.html#a73d4134257f7351180c72870359b2bbf", null ],
      [ "CNTR13", "struct_t_s_i___mem_map.html#aa09add648d77175d86d87c2d3533af74", null ],
      [ "CNTR15", "struct_t_s_i___mem_map.html#aada5f006d1b63bfb573ec56cdf21e4bc", null ],
      [ "CNTR3", "struct_t_s_i___mem_map.html#a6784d9dce99cc4d0e04e4e527513c525", null ],
      [ "CNTR5", "struct_t_s_i___mem_map.html#a16e7aed31d05ac2b570308c208471959", null ],
      [ "CNTR7", "struct_t_s_i___mem_map.html#a3c2f3ddd1d3725bef9e71fdf30a5ee8a", null ],
      [ "CNTR9", "struct_t_s_i___mem_map.html#a1792ec66ee609674ea272871f5abcf1c", null ],
      [ "GENCS", "struct_t_s_i___mem_map.html#a14380d508e161af3b794962e7c3f8abb", null ],
      [ "PEN", "struct_t_s_i___mem_map.html#a37c8a06461ca09948d6a65a1289bccd9", null ],
      [ "RESERVED_0", "struct_t_s_i___mem_map.html#ac6145aadc4fc2ef5290b0fdd2dc6822c", null ],
      [ "SCANC", "struct_t_s_i___mem_map.html#abbf29c929817b57dbec256343e066a85", null ],
      [ "THRESHOLD", "struct_t_s_i___mem_map.html#a716863c50b790ef08399633c624ad313", null ],
      [ "WUCNTR", "struct_t_s_i___mem_map.html#ae36ce42bd55889c91be08af94a07203e", null ]
    ] ],
    [ "TSI0_BASE_PTR", "group___t_s_i___peripheral.html#gaf98ea1cd15559446e0cfc1ae177751f6", null ],
    [ "TSI_BASE_PTRS", "group___t_s_i___peripheral.html#gaf0e643a8dc882d5a89dd6bb9a4ca3d16", null ],
    [ "TSI_MemMapPtr", "group___t_s_i___peripheral.html#gad1310fedc6b594554cdd760e371de570", null ]
];