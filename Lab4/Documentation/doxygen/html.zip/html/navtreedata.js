var NAVTREE =
[
  [ "Lab1", "index.html", [
    [ "Pins allocation", "page_pinalloc.html", null ],
    [ "Memory map", "page_memorymap.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_a_d_c___p_d_d_8h_source.html",
"globals_g.html",
"group___a_d_c___register___masks.html#ga9eef257b72d4181481aa5e3bf0a85732",
"group___a_i_p_s___register___masks.html#ga2fe235c806d77fa5d23c0fcac9049290",
"group___a_i_p_s___register___masks.html#ga73ae357e5b43a447abf64beaa615c037",
"group___a_i_p_s___register___masks.html#gacb65c15234320306afb9d8fd3b9b7df1",
"group___a_x_b_s___register___masks.html#ga69131fbb37b2a3eef0e0f135e265e1c0",
"group___c_a_n___register___accessor___macros.html#gad673a605367ec33ea8d07e76a92e6677",
"group___c_a_n___register___masks.html#gae30b928fb3ce512c48cb0be04af69acd",
"group___c_a_u___register___masks.html#ga36c108071b9cf5eef7d56d3b6c5bfbf8",
"group___c_a_u___register___masks.html#gaef7d0f2273eae5d892d1ee67470284b1",
"group___c_r_c___register___masks.html#ga1a323693acd9a37bb90abdc7f16ebbd8",
"group___d_a_c___register___masks.html#ga7e785d90fec3c1817fc53fea41f41644",
"group___d_d_r___register___masks.html#ga3003388b6dfca3121f66b2c6de573f3c",
"group___d_d_r___register___masks.html#gab041afdc2b1ac528355d1cdfe18f81b8",
"group___d_m_a___register___accessor___macros.html#ga20541e42162680378136b1da043ba15b",
"group___d_m_a___register___accessor___macros.html#ga85eb84f9db603a9914f8083f55c8091c",
"group___d_m_a___register___accessor___macros.html#gaf27ace6bb56c2ffc8e1248fd0964bc9c",
"group___d_m_a___register___masks.html#ga44a7a6fb709ddfc16bc99a5c4d1d0a73",
"group___d_m_a___register___masks.html#ga8d41b8ec510ae91e64c21d13721a272d",
"group___d_m_a___register___masks.html#gad8217a06faed89c0872aa38c79bfeea7",
"group___e_n_e_t___register___accessor___macros.html#ga035a6a1b5ef7ee1a23d08e308353dc14",
"group___e_n_e_t___register___masks.html#ga1e61cf8300255cf3f9873a6bd9e1ffe6",
"group___e_n_e_t___register___masks.html#gab017cc2737c10a8709398a3a47dc3ade",
"group___e_t_f___register___accessor___macros.html#ga22a177b1da19ab118f05956caf11a5da",
"group___f_b___register___masks.html#gac577e626a579979985c559866c940018",
"group___f_p_b___register___accessor___macros.html#gaa858bde712d7ddaf74a6e62c51bed1f9",
"group___f_t_m___register___accessor___macros.html#ga620872143b294eb22c847f6159f2aefd",
"group___f_t_m___register___masks.html#ga6ee8ba517c1d833d785fbe2fb0344726",
"group___g_p_i_o___register___accessor___macros.html#ga4c1b943d4d92f73c9f08d272d8fc8fe1",
"group___i2_s___register___accessor___macros.html#gabb9a8ee9dfb5ae4b28895d4cb285ae16",
"group___i_t_m___register___accessor___macros.html#ga1c080ae3f53ea5063b86fd6fe6ba264d",
"group___interrupt__vector__numbers.html#gga5f3656e2a154b64aa378a2f3856c3a8daa718be6f01474617d86d5e1a2899ef16",
"group___l_c_d_c___register___masks.html#ga7e8f5454d08880caea42b5e4119a7b2d",
"group___l_l_w_u___register___masks.html#gaceee1b1b6323ba4d33abf875718e885a",
"group___l_p_t_m_r___register___accessor___macros.html#ga7a7ca80913d5f4e2ceed4be05272267a",
"group___m_c_m___register___masks.html#ga16853921aa4b5ded12e5bf4d2c8509fb",
"group___m_p_u___register___masks.html#ga6add3ff0b896e284766090212deee537",
"group___n_f_c___register___masks.html#gabae2501177f466efc5a42232973a5a97",
"group___n_v_i_c___register___accessor___macros.html#gab286383a4e3feb0ab833f29186bb3623",
"group___n_v_i_c___register___masks.html#ga9b71b5fc158fc91d760fff1f6b315247",
"group___p_d_b___register___masks.html#ga79150887ba3f74efde99b40d3b9c5e44",
"group___p_e___types__module.html#ga073542f5b2a49dca62e3eeb042f63909",
"group___p_e___types__module.html#ga2727f70e11278d75111c554984db50bb",
"group___p_e___types__module.html#ga44aca60925f9624f935d3263fa4169e9",
"group___p_e___types__module.html#ga6786f068a2fabcf435fb5e99d1b6c0c7",
"group___p_e___types__module.html#ga89eeb36d5753c21fb55207284dcb208d",
"group___p_e___types__module.html#gaaf15d029c9eca2330c91be4a6f217469",
"group___p_e___types__module.html#gacf5f7e704d87aba90dc002ed7c0d28b4",
"group___p_e___types__module.html#gaf09fb0a2318b750571b99810ea3d2343",
"group___p_e___types__module.html#gga59054b7863240b77bde12e8762d3da5aab5f2ae40a8ba102625b7464cc5b49cfd",
"group___p_e___types__module.html#ggac01cb076a7d214b9644c76681280e031ad5fe1ab7b847aeaafa3bc7234e8710db",
"group___p_o_r_t___peripheral.html#gab166fe285bbb15b52de610f408fe25d3",
"group___p_o_r_t___register___masks.html#ga0feec5fc6b285b83c573f913c74e5c41",
"group___r_t_c___register___masks.html#ga120f7d25fec9feca0a62b6e79683e3ac",
"group___s_c_b___register___masks.html#ga6729af9d9ed3840dae99f10bb2feb44d",
"group___s_d_h_c___register___masks.html#ga35cc08217531a736cec185c65abe7f82",
"group___s_d_h_c___register___masks.html#gaecbb85d934f063d60ebf735df37b9936",
"group___s_i_m___register___masks.html#ga7a43287402d14ab06bb187be3fe36769",
"group___s_p_i___register___accessor___macros.html#ga12df97e0d55761a6643307e86ee4f61c",
"group___s_p_i___register___masks.html#gaf8ee524100dedae1cc3afb60643b2475",
"group___t_s_i___register___masks.html#gab010aabd2e3e83825b47d94614f49655",
"group___u_a_r_t___register___accessor___macros.html#gaf1364840dbdc70f6ca2931518a3f0c04",
"group___u_a_r_t___register___masks.html#gabbe5c7cb60072d535d068446606414c5",
"group___u_s_b___register___masks.html#ga69ae55ac7a03104ed013c34efa24ef43",
"group___u_s_b_h_s___register___accessor___macros.html#ga964cc695222af371ea1a94e5cdc6e71f",
"group___u_s_b_h_s___register___masks.html#ga6a4be6cad860f37b8ae898a3fdd9c067",
"group___u_s_b_h_s___register___masks.html#gaf103a158f47c90d17773c3fd048f35c2",
"group__accer__module.html#gae0a4fc3c856cfd0219b8147d61160f3e",
"struct_a_i_p_s___mem_map.html#a98bd3ff2455e9fccb9cd7d06cc090370",
"struct_d_m_a___mem_map.html#aa99ffa54a462f1c42ea1feb2e5420c73",
"struct_e_t_f___mem_map.html#ab6920fa131f508ff5a9b6817be95bed5",
"struct_l_c_d_c___mem_map.html#a8f4192a93512b0a04c71bd2f8d92590f",
"struct_l_d_d___time_date___t_date_rec.html",
"struct_o_s_c___mem_map.html#adb3c443099915a22c9951ff23c8eaa16",
"struct_t_p_i_u___mem_map.html#a70bd66aa2144dae3d99cda444fe4110d",
"union_t_packet.html#ab3ac2f9a6cfe5b6a7ae0987d21de472b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';