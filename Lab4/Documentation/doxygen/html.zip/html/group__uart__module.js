var group__uart__module =
[
    [ "__attribute__", "group__uart__module.html#ga445500277ba0e363873b34cffc015745", null ],
    [ "UART_InChar", "group__uart__module.html#ga08d2770a685ef783e586bcdf9762aa25", null ],
    [ "UART_Init", "group__uart__module.html#ga79191be14a25cdb749b49a5f2eff9bbf", null ],
    [ "UART_OutChar", "group__uart__module.html#gaa4ebf6ba59a0869e4b9f8a1408f585e9", null ],
    [ "RxFIFO", "group__uart__module.html#ga57a6bee2e32f83a4a1b52c99299794b8", null ]
];