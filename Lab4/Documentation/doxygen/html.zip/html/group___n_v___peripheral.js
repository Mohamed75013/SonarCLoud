var group___n_v___peripheral =
[
    [ "NV - Register accessor macros", "group___n_v___register___accessor___macros.html", null ],
    [ "NV Register Masks", "group___n_v___register___masks.html", null ],
    [ "NV_MemMap", "struct_n_v___mem_map.html", [
      [ "BACKKEY0", "struct_n_v___mem_map.html#ad6d790fea8e791ef5cda3685fe306a08", null ],
      [ "BACKKEY1", "struct_n_v___mem_map.html#ab43748ac2b6d99cef1a62072d17a707b", null ],
      [ "BACKKEY2", "struct_n_v___mem_map.html#af746c853a18c5e8910e556b32073f938", null ],
      [ "BACKKEY3", "struct_n_v___mem_map.html#a836e107cd6936ce8acd9279af7e9657e", null ],
      [ "BACKKEY4", "struct_n_v___mem_map.html#ae4e87676d4d9881d1d60af4176b6d6f5", null ],
      [ "BACKKEY5", "struct_n_v___mem_map.html#a46e84393478a41f6958c4f382cad11b7", null ],
      [ "BACKKEY6", "struct_n_v___mem_map.html#aa2013cbf54568a1ed52cd6205b4b0b35", null ],
      [ "BACKKEY7", "struct_n_v___mem_map.html#a398eb38f0e2b4a9da6562e42ed7a40b3", null ],
      [ "FDPROT", "struct_n_v___mem_map.html#a335c056263e0dae36f7a3bb82d08bce8", null ],
      [ "FEPROT", "struct_n_v___mem_map.html#a8de06ecef5c15ac5c29f613d79c9e491", null ],
      [ "FOPT", "struct_n_v___mem_map.html#a3a3c0ec53723a865f6686bf4696800ba", null ],
      [ "FPROT0", "struct_n_v___mem_map.html#a93d4a444c27eba9b9d8939e52440e8e8", null ],
      [ "FPROT1", "struct_n_v___mem_map.html#a87204afdff32b371c03caafdf5a07b69", null ],
      [ "FPROT2", "struct_n_v___mem_map.html#aace11e44cee29095fe7c0bf683039f57", null ],
      [ "FPROT3", "struct_n_v___mem_map.html#a944089b14b23cff0b4f8a16e13f8b9d6", null ],
      [ "FSEC", "struct_n_v___mem_map.html#acb89fbc884fb10887ef063d1aa892b29", null ]
    ] ],
    [ "FTFE_FlashConfig_BASE_PTR", "group___n_v___peripheral.html#ga824c84d1d5dcc180128d85f4f676b4c5", null ],
    [ "NV_BASE_PTRS", "group___n_v___peripheral.html#ga1e44e66a8945b675dcebb6fbd6bdc85b", null ],
    [ "NV_MemMapPtr", "group___n_v___peripheral.html#ga9aac431b01e6b976f2f4e32409ab725f", null ]
];