var group__rtc__module =
[
    [ "__attribute__", "group__rtc__module.html#ga445500277ba0e363873b34cffc015745", null ],
    [ "RTC_Get", "group__rtc__module.html#ga46e1f15e3b27e2de58d7f213a3bc865d", null ],
    [ "RTC_Init", "group__rtc__module.html#ga0faa546897ba438dfbd6efbfe6036a67", null ],
    [ "RTC_Set", "group__rtc__module.html#gacbe916e4fad6bfc2ffcde604fa6afb52", null ]
];