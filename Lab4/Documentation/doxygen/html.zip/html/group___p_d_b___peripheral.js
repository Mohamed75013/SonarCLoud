var group___p_d_b___peripheral =
[
    [ "PDB - Register accessor macros", "group___p_d_b___register___accessor___macros.html", null ],
    [ "PDB Register Masks", "group___p_d_b___register___masks.html", null ],
    [ "PDB_MemMap", "struct_p_d_b___mem_map.html", [
      [ "C1", "struct_p_d_b___mem_map.html#a7f3d427467fd70574b129f2ecd5a84ed", null ],
      [ "CH", "struct_p_d_b___mem_map.html#a6542465269e0a946a58dd131602a29c7", null ],
      [ "CNT", "struct_p_d_b___mem_map.html#a2e90754ac53cdee38eec08416fee494e", null ],
      [ "DAC", "struct_p_d_b___mem_map.html#a8834abb19035005831da467b2c045007", null ],
      [ "DLY", "struct_p_d_b___mem_map.html#a101a3b427fd438fc5dd9069f9d3f31d6", null ],
      [ "IDLY", "struct_p_d_b___mem_map.html#abbda47481fef54f3ab340fec07c8b809", null ],
      [ "INT", "struct_p_d_b___mem_map.html#a94d5425758d6d4b2d3141a05603ff7d1", null ],
      [ "INTC", "struct_p_d_b___mem_map.html#a37fb3d809a70ce9bd67dcc87483064c5", null ],
      [ "MOD", "struct_p_d_b___mem_map.html#a01bd648b1caa9b6626636fce386b496d", null ],
      [ "PODLY", "struct_p_d_b___mem_map.html#a69081c41b606ea7a699a67e266a785d5", null ],
      [ "POEN", "struct_p_d_b___mem_map.html#a259dc7b16cc8f12022cb6a5befb1660c", null ],
      [ "RESERVED_0", "struct_p_d_b___mem_map.html#a26f57ce034a92374881fec262e7f9df6", null ],
      [ "RESERVED_1", "struct_p_d_b___mem_map.html#a7c028c218b26078db2795a35ab315266", null ],
      [ "S", "struct_p_d_b___mem_map.html#afbd33089148cbb97dedff82c1c91c46d", null ],
      [ "SC", "struct_p_d_b___mem_map.html#a10fb0324a394cc747b6f7d8b4c811b57", null ]
    ] ],
    [ "PDB0_BASE_PTR", "group___p_d_b___peripheral.html#ga8e197b7c43fd7a0bf1a38caa1918b7b5", null ],
    [ "PDB_BASE_PTRS", "group___p_d_b___peripheral.html#ga6dce940c99da63282b1d28f65ed75293", null ],
    [ "PDB_MemMapPtr", "group___p_d_b___peripheral.html#ga99a192ea14b33afb792a0de304e131be", null ]
];