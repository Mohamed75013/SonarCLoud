var group___c_m_p___peripheral =
[
    [ "CMP - Register accessor macros", "group___c_m_p___register___accessor___macros.html", null ],
    [ "CMP Register Masks", "group___c_m_p___register___masks.html", null ],
    [ "CMP_MemMap", "struct_c_m_p___mem_map.html", [
      [ "CR0", "struct_c_m_p___mem_map.html#ad56a4dbaba4426c89e4d9b256173ab84", null ],
      [ "CR1", "struct_c_m_p___mem_map.html#ab790f5d18ef53ba0c9cfc2b5f3ce6668", null ],
      [ "DACCR", "struct_c_m_p___mem_map.html#a64ad86546fe53058b6fdd5ca1252f7c2", null ],
      [ "FPR", "struct_c_m_p___mem_map.html#aa793447f43fa77759b6eaf1620bed4bc", null ],
      [ "MUXCR", "struct_c_m_p___mem_map.html#a3b48de300c4b4116ebb942659a2948a2", null ],
      [ "SCR", "struct_c_m_p___mem_map.html#a3fe55f0243869b50fc54acb9c194d970", null ]
    ] ],
    [ "CMP0_BASE_PTR", "group___c_m_p___peripheral.html#ga5a7a6b1d0743a05435ba5cb2dc2b3431", null ],
    [ "CMP1_BASE_PTR", "group___c_m_p___peripheral.html#ga91e89d9d49a3f251dcd9026ad403a3e8", null ],
    [ "CMP2_BASE_PTR", "group___c_m_p___peripheral.html#ga732cbf43f95d2d1cd01b4204263940ab", null ],
    [ "CMP3_BASE_PTR", "group___c_m_p___peripheral.html#ga793306a1014f5112aa61f346fe3bb2c0", null ],
    [ "CMP_BASE_PTRS", "group___c_m_p___peripheral.html#gacc69654296499d45b2060956a3c8e97f", null ],
    [ "CMP_MemMapPtr", "group___c_m_p___peripheral.html#ga6f5d370df3839e41b771c2d0b89cbb83", null ]
];