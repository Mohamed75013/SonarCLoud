var accel_8h =
[
    [ "TAccelSetup", "struct_t_accel_setup.html", "struct_t_accel_setup" ],
    [ "TAccelData", "union_t_accel_data.html", "union_t_accel_data" ],
    [ "TAccelMode", "accel_8h.html#aa4058f7fc9c8d14d82445b6e61702845", [
      [ "ACCEL_POLL", "accel_8h.html#aa4058f7fc9c8d14d82445b6e61702845a52839dbed033685b61d14058b4145ef8", null ],
      [ "ACCEL_INT", "accel_8h.html#aa4058f7fc9c8d14d82445b6e61702845a9cb6daa9151caca352b1db046abf69a6", null ]
    ] ],
    [ "__attribute__", "group__accer__module.html#ga445500277ba0e363873b34cffc015745", null ],
    [ "Accel_Init", "group__accer__module.html#ga07fa534f6ebb0b37572e9444be88b4a8", null ],
    [ "Accel_ReadXYZ", "group__accer__module.html#ga8cc8e053f2474e24cb761f1de0f769d8", null ],
    [ "Accel_SetMode", "group__accer__module.html#ga4f26113eba1169f1d886f8236626f4a7", null ]
];