var group__i2c__module =
[
    [ "__attribute__", "group__i2c__module.html#ga445500277ba0e363873b34cffc015745", null ],
    [ "I2C_Init", "group__i2c__module.html#gaf5a1731e099294a5bda6ef0f14aeb547", null ],
    [ "I2C_IntRead", "group__i2c__module.html#ga3685b2f03da2fa00b0cb671a0cce4f3f", null ],
    [ "I2C_PollRead", "group__i2c__module.html#ga3692682bb1cb84e1a3d0c31195451bd9", null ],
    [ "I2C_SelectSlaveDevice", "group__i2c__module.html#ga0d6844ce590bbf5cc557fdf0747ad551", null ],
    [ "I2C_Write", "group__i2c__module.html#gacaac94d86a7213791fb691d57c6f278b", null ]
];