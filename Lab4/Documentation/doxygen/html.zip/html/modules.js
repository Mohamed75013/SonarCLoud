var modules =
[
    [ "accel documentation", "group__accer__module.html", "group__accer__module" ],
    [ "FIFO module documentation", "group__fifo__module.html", "group__fifo__module" ],
    [ "flash module documentation", "group__flash__module.html", "group__flash__module" ],
    [ "FTM module documentation", "group__ftm__module.html", "group__ftm__module" ],
    [ "I2C module documentation", "group__i2c__module.html", "group__i2c__module" ],
    [ "LEDs module documentation", "group__leds__module.html", "group__leds__module" ],
    [ "main module documentation", "group__main__module.html", "group__main__module" ],
    [ "median module documentation", "group__median__module.html", "group__median__module" ],
    [ "packet module documentation", "group__packet__module.html", "group__packet__module" ],
    [ "PIT module documentation", "group__pit__module.html", "group__pit__module" ],
    [ "RTC module documentation", "group__rtc__module.html", "group__rtc__module" ],
    [ "UART module documentation", "group__uart__module.html", "group__uart__module" ],
    [ "Cpu module documentation", "group___cpu__module.html", "group___cpu__module" ],
    [ "PE_Const module documentation", "group___p_e___const__module.html", "group___p_e___const__module" ],
    [ "PE_Error module documentation", "group___p_e___error__module.html", "group___p_e___error__module" ],
    [ "PE_LDD module documentation", "group___p_e___l_d_d__module.html", "group___p_e___l_d_d__module" ],
    [ "PE_Types module documentation", "group___p_e___types__module.html", "group___p_e___types__module" ],
    [ "Vectors module documentation", "group___vectors__module.html", null ],
    [ "Interrupt vector numbers", "group___interrupt__vector__numbers.html", "group___interrupt__vector__numbers" ],
    [ "Peripheral type defines", "group___peripheral__defines.html", "group___peripheral__defines" ],
    [ "Backward Compatibility", "group___backward___compatibility___symbols.html", null ]
];