var group___n_v_i_c___peripheral =
[
    [ "NVIC - Register accessor macros", "group___n_v_i_c___register___accessor___macros.html", null ],
    [ "NVIC Register Masks", "group___n_v_i_c___register___masks.html", null ],
    [ "NVIC_MemMap", "struct_n_v_i_c___mem_map.html", [
      [ "IABR", "struct_n_v_i_c___mem_map.html#ac2813e9c133793584e82f645f7e5c2ad", null ],
      [ "ICER", "struct_n_v_i_c___mem_map.html#a44632f5cb66efc81e73970988a899334", null ],
      [ "ICPR", "struct_n_v_i_c___mem_map.html#a18f7154bcaf967d002d2cb1bd480a66a", null ],
      [ "IP", "struct_n_v_i_c___mem_map.html#a2c1a78a8c4dc2c05595641b28e771dee", null ],
      [ "ISER", "struct_n_v_i_c___mem_map.html#abd212d27ccda188473e4e918f0cc8aff", null ],
      [ "ISPR", "struct_n_v_i_c___mem_map.html#a1067a671b702e7fac08c0733131e8454", null ],
      [ "RESERVED_0", "struct_n_v_i_c___mem_map.html#a672371a65afa3a33d6d4bf26f54014fe", null ],
      [ "RESERVED_1", "struct_n_v_i_c___mem_map.html#a4fc17c3f34f5db09bc5b3594324a2b67", null ],
      [ "RESERVED_2", "struct_n_v_i_c___mem_map.html#a6452a50947e86da5cc01df353d697c8b", null ],
      [ "RESERVED_3", "struct_n_v_i_c___mem_map.html#a002afb1e428bb77c95ac38cb11c19e9d", null ],
      [ "RESERVED_4", "struct_n_v_i_c___mem_map.html#a89f6bffb5c9ffeeb4a53e75be5bd8387", null ],
      [ "RESERVED_5", "struct_n_v_i_c___mem_map.html#a15bcaf2702d7c14e869fefc29a56da5d", null ],
      [ "STIR", "struct_n_v_i_c___mem_map.html#a417658a729224de65052153f5c2cc419", null ]
    ] ],
    [ "NVIC_BASE_PTR", "group___n_v_i_c___peripheral.html#ga28f0a055d0c218e16d1fc7b13ff0caa5", null ],
    [ "NVIC_BASE_PTRS", "group___n_v_i_c___peripheral.html#ga25b6ce0c871e09199e515cbb1716fe26", null ],
    [ "NVIC_MemMapPtr", "group___n_v_i_c___peripheral.html#ga685d87c766bb24fb3330aa8cc48fa0e7", null ]
];