var struct_core_debug___mem_map =
[
    [ "base_DCRDR", "struct_core_debug___mem_map.html#aac76a717b2aba2ccbf75e020cc71fb3e", null ],
    [ "base_DCRSR", "struct_core_debug___mem_map.html#ad9c98f7390e5d3a6b54df56ddea32e8b", null ],
    [ "base_DEMCR", "struct_core_debug___mem_map.html#a13a099e668fcb3587b2cd6eb8f8608d5", null ],
    [ "base_DHCSR_Read", "struct_core_debug___mem_map.html#a4968901505f61e2a98c9196a8ac7584b", null ],
    [ "base_DHCSR_Write", "struct_core_debug___mem_map.html#a57de52c8c1eb5789546543f2408ce487", null ]
];