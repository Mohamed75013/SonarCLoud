var modules =
[
    [ "main module documentation", "group__main__module.html", null ],
    [ "Cpu module documentation", "group___cpu__module.html", "group___cpu__module" ],
    [ "PE_Const module documentation", "group___p_e___const__module.html", "group___p_e___const__module" ],
    [ "PE_Error module documentation", "group___p_e___error__module.html", "group___p_e___error__module" ],
    [ "PE_LDD module documentation", "group___p_e___l_d_d__module.html", "group___p_e___l_d_d__module" ],
    [ "PE_Types module documentation", "group___p_e___types__module.html", "group___p_e___types__module" ],
    [ "Vectors module documentation", "group___vectors__module.html", null ],
    [ "Interrupt vector numbers", "group___interrupt__vector__numbers.html", "group___interrupt__vector__numbers" ],
    [ "Peripheral type defines", "group___peripheral__defines.html", "group___peripheral__defines" ],
    [ "Backward Compatibility", "group___backward___compatibility___symbols.html", null ]
];