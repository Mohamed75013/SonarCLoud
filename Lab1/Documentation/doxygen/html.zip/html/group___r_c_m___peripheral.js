var group___r_c_m___peripheral =
[
    [ "RCM - Register accessor macros", "group___r_c_m___register___accessor___macros.html", null ],
    [ "RCM Register Masks", "group___r_c_m___register___masks.html", null ],
    [ "RCM_MemMap", "struct_r_c_m___mem_map.html", [
      [ "MR", "struct_r_c_m___mem_map.html#a0e7b707ffc94ef2a3c49a5ca51acc6c9", null ],
      [ "RESERVED_0", "struct_r_c_m___mem_map.html#a5eaf5837cabca1357756d67c06f69ca6", null ],
      [ "RESERVED_1", "struct_r_c_m___mem_map.html#ac5c6255c10a59b7d083d7721ebc7a580", null ],
      [ "RPFC", "struct_r_c_m___mem_map.html#ace89c039f8342f8b5dd26c3c7b8309a2", null ],
      [ "RPFW", "struct_r_c_m___mem_map.html#ac458f95f6aa234285f568694a5b8240d", null ],
      [ "SRS0", "struct_r_c_m___mem_map.html#aa28b91bdb2e1acc454f7bcb9ad26efb7", null ],
      [ "SRS1", "struct_r_c_m___mem_map.html#a8e7926e6f51e64e63e5ed3adb7aee612", null ]
    ] ],
    [ "RCM_BASE_PTR", "group___r_c_m___peripheral.html#ga25ab3aa8d593d455ed36a52c77f88234", null ],
    [ "RCM_BASE_PTRS", "group___r_c_m___peripheral.html#gad8549fec4a09b0b485983beadfc3a5fb", null ],
    [ "RCM_MemMapPtr", "group___r_c_m___peripheral.html#ga787b1c58d947f0b81c2502227dd0396b", null ]
];