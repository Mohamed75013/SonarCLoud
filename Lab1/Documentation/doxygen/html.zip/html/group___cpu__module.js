var group___cpu__module =
[
    [ "TCpuClockConfiguration", "struct_t_cpu_clock_configuration.html", [
      [ "cpu_bus_clk_hz", "struct_t_cpu_clock_configuration.html#a60f271b3fc223c5c27e62c977d848c13", null ],
      [ "cpu_core_clk_hz", "struct_t_cpu_clock_configuration.html#a36bc0e0d9555a406ba4d76260bf6c0e3", null ],
      [ "cpu_erclk32k_clk_hz", "struct_t_cpu_clock_configuration.html#a3f68e3893f7dec551e938a909929687b", null ],
      [ "cpu_flash_clk_hz", "struct_t_cpu_clock_configuration.html#a1d7797ce2337ae8366fd75ff7f4bf734", null ],
      [ "cpu_flexbus_clk_hz", "struct_t_cpu_clock_configuration.html#ad642c26ae7fe34013e20f9bd2ad83a16", null ],
      [ "cpu_mcgff_clk_hz", "struct_t_cpu_clock_configuration.html#a5bd9b1235d0f85073ed01c126782d898", null ],
      [ "cpu_mcgir_clk_hz", "struct_t_cpu_clock_configuration.html#a67137a81d750b2d7267e3c927a1992f4", null ],
      [ "cpu_oscer_clk_hz", "struct_t_cpu_clock_configuration.html#a8573f3896f85f97201ef2d6252d99905", null ],
      [ "cpu_pll_fll_clk_hz", "struct_t_cpu_clock_configuration.html#a0ad457ff18a2493e1f4a0e98ceca6cc4", null ],
      [ "cpu_usb_clk_hz", "struct_t_cpu_clock_configuration.html#af90ef1d5123945a1412d5549f7985389", null ]
    ] ],
    [ "tVectorTable", "structt_vector_table.html", [
      [ "__fun", "structt_vector_table.html#a6001c7c57c392674cadaf831203e4606", null ],
      [ "__ptr", "structt_vector_table.html#a324d365e9c8c6c033f4edbc906f94844", null ]
    ] ],
    [ "PE_CpuClockConfigurations", "group___cpu__module.html#gab69281f0e90d16198a5595ed7f471441", null ]
];