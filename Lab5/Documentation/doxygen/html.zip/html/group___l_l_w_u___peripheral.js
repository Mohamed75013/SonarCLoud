var group___l_l_w_u___peripheral =
[
    [ "LLWU - Register accessor macros", "group___l_l_w_u___register___accessor___macros.html", null ],
    [ "LLWU Register Masks", "group___l_l_w_u___register___masks.html", null ],
    [ "LLWU_MemMap", "struct_l_l_w_u___mem_map.html", [
      [ "F1", "struct_l_l_w_u___mem_map.html#acb7ec83bb70ec1313cd2e0682b1ee75c", null ],
      [ "F2", "struct_l_l_w_u___mem_map.html#a108405432abc40a34ccbb2c0d7ecfdb4", null ],
      [ "F3", "struct_l_l_w_u___mem_map.html#a47d12785dc2fc2afa376e2398c7619f1", null ],
      [ "FILT1", "struct_l_l_w_u___mem_map.html#a80ad19326e9bf7209c71d7955e4ef044", null ],
      [ "FILT2", "struct_l_l_w_u___mem_map.html#a84fdf2d8e40d91c4ad620512aaca152b", null ],
      [ "ME", "struct_l_l_w_u___mem_map.html#ae8dea688fae93c1a5f9dd22b70cdc5cf", null ],
      [ "PE1", "struct_l_l_w_u___mem_map.html#abb0c4dd1142a84dc991e6dda4a8381d6", null ],
      [ "PE2", "struct_l_l_w_u___mem_map.html#a53d86f5153bce17f9927472da4fade5a", null ],
      [ "PE3", "struct_l_l_w_u___mem_map.html#a96a722e1ae66ee87b88407ef622cf243", null ],
      [ "PE4", "struct_l_l_w_u___mem_map.html#a61ec3534039e161c5c71ea7f290f23d5", null ],
      [ "RST", "struct_l_l_w_u___mem_map.html#a95c7e36f114e8ac7f235ad8ef335f1cf", null ]
    ] ],
    [ "LLWU_BASE_PTR", "group___l_l_w_u___peripheral.html#ga89c97b9e8756088cb3d8617c022ae6ac", null ],
    [ "LLWU_BASE_PTRS", "group___l_l_w_u___peripheral.html#ga4826d688973513cc02a2f1d4f67c336b", null ],
    [ "LLWU_MemMapPtr", "group___l_l_w_u___peripheral.html#ga03cfefad45ecbfeb2cd16eb85ccfe186", null ]
];