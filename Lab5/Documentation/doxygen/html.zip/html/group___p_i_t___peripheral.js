var group___p_i_t___peripheral =
[
    [ "PIT - Register accessor macros", "group___p_i_t___register___accessor___macros.html", null ],
    [ "PIT Register Masks", "group___p_i_t___register___masks.html", null ],
    [ "PIT_MemMap", "struct_p_i_t___mem_map.html", [
      [ "CHANNEL", "struct_p_i_t___mem_map.html#aa7a105b8dca38d6f5e0e51d796012bca", null ],
      [ "CVAL", "struct_p_i_t___mem_map.html#a7d3d1a5913a28cfb4ca0e120ebf37087", null ],
      [ "LDVAL", "struct_p_i_t___mem_map.html#ad664bbe0f8b53ee1e533727db4da3fb2", null ],
      [ "MCR", "struct_p_i_t___mem_map.html#a99390c5764693e07c37d40ead441a7a4", null ],
      [ "RESERVED_0", "struct_p_i_t___mem_map.html#afd7d4076393c069e0ef7b76ad95ef752", null ],
      [ "TCTRL", "struct_p_i_t___mem_map.html#a567cdea5c7d615341f95f1438020a7e1", null ],
      [ "TFLG", "struct_p_i_t___mem_map.html#add88e740d4ec7a83e66cf9ad79cd027a", null ]
    ] ],
    [ "PIT_BASE_PTR", "group___p_i_t___peripheral.html#ga70be45f58402a8e6d2ce4df7b23aa41c", null ],
    [ "PIT_BASE_PTRS", "group___p_i_t___peripheral.html#ga403e0ed71b80cfe3e085fe6b56b5eff0", null ],
    [ "PIT_MemMapPtr", "group___p_i_t___peripheral.html#ga4efe9d2676c775562cb282254af9a937", null ]
];