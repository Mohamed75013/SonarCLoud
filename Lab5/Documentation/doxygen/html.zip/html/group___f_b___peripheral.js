var group___f_b___peripheral =
[
    [ "FB - Register accessor macros", "group___f_b___register___accessor___macros.html", null ],
    [ "FB Register Masks", "group___f_b___register___masks.html", null ],
    [ "FB_MemMap", "struct_f_b___mem_map.html", [
      [ "CS", "struct_f_b___mem_map.html#abc032673dc539f4dce87fbaf7ed7bf04", null ],
      [ "CSAR", "struct_f_b___mem_map.html#aa59ea1aff2f195dc7d41ef8611884381", null ],
      [ "CSCR", "struct_f_b___mem_map.html#a7a1e48a5fde6382a076243009f5c0846", null ],
      [ "CSMR", "struct_f_b___mem_map.html#a02c1e1542339e83d168a52e763f60228", null ],
      [ "CSPMCR", "struct_f_b___mem_map.html#a7876f1f5e2d0718968b09242af73b600", null ],
      [ "RESERVED_0", "struct_f_b___mem_map.html#ab4544394653b4ae4c41edbad89696b61", null ]
    ] ],
    [ "FB_BASE_PTR", "group___f_b___peripheral.html#gace69013248279ed94480b3d6f6aa9fa6", null ],
    [ "FB_BASE_PTRS", "group___f_b___peripheral.html#ga0aa36a3189de1e68b58234782768941a", null ],
    [ "FB_MemMapPtr", "group___f_b___peripheral.html#gaebb09d71e958c6590cf946799cb4aa11", null ]
];